public class AccountMain {

	public static void main(String[] args) {
	AccountMain account=new AccountMain();
		account.details();
				

	}
	public void details()
	{
		Account account=new Account();
		Person person=new Person();
		Random rd = new Random();
		person.setName("smith");
		person.setAge(45);
		account.setAccNum(rd.nextLong());
		account.setBalance(2000);
		account.setPerson(person);
		Account account1=new Account();
		Person person1=new Person();
		person1.setName("kathy");
		person1.setAge(30);
		account1.setAccNum(rd.nextLong());
		account1.setBalance(3000);
		account1.setPerson(person1);
		account.deposit(2000);
		account1.withdraw(2000);
		System.out.println(account.getBalance()+" "+account.getAccNum());
		System.out.println(account1.getBalance()+" "+account.getAccNum());
	}

}
