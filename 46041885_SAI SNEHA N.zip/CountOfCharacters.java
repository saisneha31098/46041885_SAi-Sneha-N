package Lab3;

public class CountOfCharacters {
	public static void main(String args[])
	{
		String arr="A paragraph is a group of words put together to form a "
				+ "group that is usually longer than a sentence. "
				+ "Paragraphs are often made up of several sentences. "
				+ "There are usually between three and eight sentences. ";
		int count=0,characters=0;
		for(int i=0;i<arr.length();i++)
		{
			if(arr.charAt(i)==' ')
			{
				count++;
			}
			else
			{
				characters++;
			}
		}
		System.out.println(count+" "+characters);
	}

}
