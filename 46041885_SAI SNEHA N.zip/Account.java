

public class Account {
	private long accNum;
	private double balance;
	private Person person;
	public void deposit(double deposit)
	{
		setBalance(balance+deposit);
	}
	public void withdraw(double withdraw)
	{
		setBalance(balance-withdraw);
	}
	
	
	public long getAccNum() {
		return accNum;
	}
	public void setAccNum(long accNum) {
		this.accNum = accNum;
	}
	public double getBalance() {
		return balance;
	}
	public void setBalance(double balance) {
		this.balance = balance;
	}
	public Person getPerson() {
		return person;
	}
	public void setPerson(Person person) {
		this.person = person;
	}
	
}
