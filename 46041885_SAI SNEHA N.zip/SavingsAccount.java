

public class SavingsAccount extends Account {
	private final double minBalance=500;
	@Override
	public void withdraw(double withdraw)
	{
		if(getBalance()>=minBalance)
		{
			System.out.println("nooo balance");
		}
		else
		{
			setBalance(getBalance()-withdraw);
		}
		
	}
	
	
	

}
